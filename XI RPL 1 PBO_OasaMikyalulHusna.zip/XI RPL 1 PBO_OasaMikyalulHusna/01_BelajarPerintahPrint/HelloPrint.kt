fun main(){
println("Biodata Diri")
print("Nama: ")
println("Oasa")
print("Jenis kelamin: ")
println("Perempuan")
print("usia: ")
println(15)
print("Alamat: ")
print("Kab. Bandung")
}