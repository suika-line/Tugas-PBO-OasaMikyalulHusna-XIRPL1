fun main(){
println("Ganbatte, ganbatte!")
}