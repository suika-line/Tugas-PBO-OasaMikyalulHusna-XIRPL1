fun main(){
      var nama="Oasa"
      var usia=13
      var jeniskelamin='P'
      
      println("-Hello Variable- \n\n")
      println("Nama $nama")
      println("Usia $usia")
      println("Jenis Kelamin $jeniskelamin")
      usia=15
      println("Usia Betulnya $usia")
}