fun main(){
var rumusPersegiPanjang ="P x P"
val rumusSegitiga="A x T / 2"
val rumusLingkaran="22/7"

println("Latihan Variable Val \n \n")
println("Info Rumus Persegi Panjang : $rumusPersegiPanjang \n")
println("Info Rumus Segitiga : $rumusSegitiga")
println("Info Rumus Lingkaran: $rumusLingkaran")
rumusPersegiPanjang= "PxL"
print("Info Rumus Persegi Panjang OK : $rumusPersegiPanjang \n")
}