fun main() {
	//Ini adalah type angka
	var harga:int =1_000_000_000
	//Ini adalah tipe Character
	var golonganDarah:char= 'A'
	//ini adalah type symbol atau karakter(string)
	var nama:String ="Oasa Mikyalul"
	//ini adalah type boolean/logika
	var operasiLogika:boolean= (5<=5)
	
	println(harga)
	println(golonganDarah)
	println(nama)
	println(operasiLogika)
}